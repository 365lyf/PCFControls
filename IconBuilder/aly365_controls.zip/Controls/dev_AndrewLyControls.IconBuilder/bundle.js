var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./IconBuilder/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./IconBuilder/index.ts":
/*!******************************!*\
  !*** ./IconBuilder/index.ts ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.IconBuilder = void 0;\n\nvar IconBuilder =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function IconBuilder() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  IconBuilder.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this._container = document.createElement(\"div\");\n    this.i_div_element = document.createElement(\"div\");\n    this.i_element = document.createElement(\"i\");\n    this.label_element = document.createElement(\"label\");\n    this.noti_span_element = document.createElement(\"span\"); // retrieve manifest inputs\n\n    this._fa_classname = context.parameters.fontAwesomeClassName.formatted ? context.parameters.fontAwesomeClassName.formatted : \"fa fa-home\";\n    this._iconsize = context.parameters.iconSize.raw ? context.parameters.iconSize.raw : 40;\n    this._fontsize = context.parameters.fontSize.raw ? context.parameters.fontSize.raw : 12;\n    this._fontcolor = context.parameters.fontColor.raw ? context.parameters.fontColor.raw : \"#A7A7A7\";\n    this._title = context.parameters.title.raw ? context.parameters.title.raw : \"Sample\";\n    this._notifycount = context.parameters.notiCount.raw ? context.parameters.notiCount.raw : 0;\n    this._notibubblecolor = context.parameters.notiBubbleColor.raw ? context.parameters.notiBubbleColor.raw : \"green\"; // set span (notification)\n\n    this.noti_span_element.innerHTML = this._notifycount.toString();\n\n    if (this._notifycount > 0) {\n      this.noti_span_element.setAttribute(\"style\", \"position:absolute;background-color:\" + this._notibubblecolor + \";padding: 2px 5px 2px 6px;color: white;font-size: 0.65em;border-radius: 50%;box-shadow: 1px 1px 1px gray;display:inline;\");\n    } else {\n      this.noti_span_element.setAttribute(\"style\", \"position:absolute;background-color:\" + this._notibubblecolor + \";padding: 2px 5px 2px 6px;color: white;font-size: 0.65em;border-radius: 50%;box-shadow: 1px 1px 1px gray;display:none;\");\n    }\n\n    this.i_div_element.appendChild(this.noti_span_element); // set i element (icon)\n\n    this.i_element.setAttribute(\"class\", this._fa_classname);\n    this.i_element.setAttribute(\"style\", \"font-size: \" + this._iconsize + \"px; color: \" + this._fontcolor);\n    this.i_div_element.appendChild(this.i_element);\n\n    this._container.appendChild(this.i_div_element); // set a element (title)\n\n\n    this.label_element.innerHTML = this._title;\n    this.label_element.setAttribute(\"style\", \"text-align: center; font-size: \" + this._fontsize + \"px; color: \" + this._fontcolor);\n\n    this._container.appendChild(this.label_element);\n\n    container.appendChild(this._container); // Add the FontAwesome Stylesheet\n\n    var link = document.createElement(\"link\");\n    link.id = \"FontAwesomeURL\";\n    link.rel = \"stylesheet\";\n    link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'; // Add the request on the head of the document\n\n    document.getElementsByTagName(\"head\")[0].appendChild(link);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  IconBuilder.prototype.updateView = function (context) {\n    // Add code to update control view\n    this._fa_classname = context.parameters.fontAwesomeClassName.formatted ? context.parameters.fontAwesomeClassName.formatted : \"fa fa-home\";\n    this._iconsize = context.parameters.iconSize.raw ? context.parameters.iconSize.raw : 40;\n    this._fontsize = context.parameters.fontSize.raw ? context.parameters.fontSize.raw : 12;\n    this._fontcolor = context.parameters.fontColor.raw ? context.parameters.fontColor.raw : \"#A7A7A7\";\n    this._title = context.parameters.title.raw ? context.parameters.title.raw : \"Sample\";\n    this._notifycount = context.parameters.notiCount.raw ? context.parameters.notiCount.raw : 0;\n    this._notibubblecolor = context.parameters.notiBubbleColor.raw ? context.parameters.notiBubbleColor.raw : \"green\"; // val is the default when debugging\n\n    this.i_element.setAttribute(\"class\", this._fa_classname);\n    this.i_element.setAttribute(\"style\", \"font-size: \" + this._iconsize + \"px; color: \" + this._fontcolor);\n    this.label_element.innerHTML = this._title;\n    this.label_element.setAttribute(\"style\", \"text-align: center; font-size: \" + this._fontsize + \"px; color: \" + this._fontcolor); // set notification bubble\n\n    this.noti_span_element.innerHTML = this._notifycount.toString();\n\n    if (this._notifycount > 0) {\n      this.noti_span_element.setAttribute(\"style\", \"position:absolute;background-color:\" + this._notibubblecolor + \";padding: 2px 5px 2px 6px;color: white;font-size: 0.65em;border-radius: 50%;box-shadow: 1px 1px 1px gray;display:inline;\");\n    } else {\n      this.noti_span_element.setAttribute(\"style\", \"position:absolute;background-color:\" + this._notibubblecolor + \";padding: 2px 5px 2px 6px;color: white;font-size: 0.65em;border-radius: 50%;box-shadow: 1px 1px 1px gray;display:none;\");\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  IconBuilder.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  IconBuilder.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return IconBuilder;\n}();\n\nexports.IconBuilder = IconBuilder;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./IconBuilder/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('AndrewLyControls.IconBuilder', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.IconBuilder);
} else {
	var AndrewLyControls = AndrewLyControls || {};
	AndrewLyControls.IconBuilder = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.IconBuilder;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}